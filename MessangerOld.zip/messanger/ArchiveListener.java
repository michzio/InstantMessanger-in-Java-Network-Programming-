package messanger;

import model.Contact;

/**
 * Interfejs listenera zdarzeń okna dodawania kontaktów
 **/
public interface ArchiveListener
{
    public void archiveDialogClosed();
};