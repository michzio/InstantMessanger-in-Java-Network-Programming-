{\rtf1\ansi\ansicpg1252\cocoartf1265\cocoasubrtf190
{\fonttbl\f0\fnil\fcharset0 Menlo-Regular;}
{\colortbl;\red255\green255\blue255;}
\paperw11900\paperh16840\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\pard\tx560\tx1120\tx1680\tx2240\tx2800\tx3360\tx3920\tx4480\tx5040\tx5600\tx6160\tx6720\pardirnatural

\f0\fs22 \cf0 \CocoaLigature0 Aby uzyska\uc0\u263  dost\u281 p do bazy danych SQLite z programu napisanego w JAVA nale\u380 y \
w Unix/Mac shell wykona\uc0\u263  nast\u281 puj\u261 c\u261  komend\u281 : \
1.) BASH\
$ export CLASSPATH=$CLASSPATH:/java/classes:/Users/michzio/Developer/ProgramowanieSieciowe/cw6/sqlite-jdbc-3.7.2.jar\
\
\uc0\u379 eby zobaczy\u263  zmienne \u347 rodowiskowe CLASSPATH mo\u380 na wykona\u263 \
@ echo $CLASSPATH}